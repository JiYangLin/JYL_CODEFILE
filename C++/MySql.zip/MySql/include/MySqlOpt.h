﻿#pragma once
#include "mysql.h"

#ifdef _WIN64
#pragma comment(lib,"libmysql64.lib")	
#else
#pragma comment(lib,"libmysql32.lib")
#endif




/*
 Blob	    最大长度65535个字节(2^16-1) 64kb
 Text	    最大长度65535个字节(2^16-1) 64kb
 MediumBlob	最大长度 16777215 个字节(2^24-1) 16M
 MediumText	最大长度 16777215 个字节(2^24-1) 16M
 LongBlob	最大长度4294967295个字节 (2^32-1) 4G
 LongText	最大长度4294967295个字节 (2^32-1) 4G


 show VARIABLES like '%max_allowed_packet%';
 %ProgramData%\MySQL\MySQL Server 5.6\my.ini
 max_allowed_packet=4M
*/



/*
//连接
MYSQL    mysql;
if (mysql_init(&mysql) == NULL)  return ;
if (mysql_real_connect(&mysql, "127.0.0.1", "root", "root", "DBName", 3306, NULL, 0) == NULL) return ;
if (mysql_set_character_set(&mysql, "GBK") != 0)  return ;

//关闭
mysql_close(&mysql);


//执行sql
if (mysql_query(&mysql, sql, sqlstrLen) != 0) {//不能用于语句包含二进制数据
    printf("erro:%s/n", mysql_error(&mysql));
}

if (mysql_real_query(&mysql, sql, sqlstrLen) != 0) {//可以包含二进制数据
    printf("erro:%s/n", mysql_error(&mysql));
}



//读取数据
const char *sql = "SELECT * FROM tableName";
if (mysql_query(&mysql, sql) != 0) return 0;
MYSQL_RES *SQLres = mysql_store_result(&mysql);
if (SQLres == NULL) return 0;

MYSQL_ROW rowValue;
int colNum = mysql_num_fields(SQLres);//表列数
while (rowValue = mysql_fetch_row(SQLres))
{
unsigned long *length = mysql_fetch_lengths(SQLres);//每列的长度，在mysql_fetch_row后调用
int colFetch = 0;

char *val = rowValue[colFetch];
int  valLen = length[colFetch];

}
mysql_free_result(SQLres);



//插入大数据
//pFileBuf,FileLen
int sqlStrBufLen = FileLen * 2;
char *sql = new char[sqlStrBufLen];
memset(sql, 0, sqlStrBufLen);
sprintf_s(sql, sqlStrBufLen,"INSERT INTO tableName(columName) VALUE (");
char *p = sql + strlen(sql);
*p++= '\'';
p += mysql_real_escape_string(&mysql, p, pFileBuf, FileLen);
*p++ = '\'';
*p++ = ')';

int sqlStrLen = (unsigned int)(p - sql);
if (mysql_real_query(&mysql, sql, sqlStrLen) != 0) {
printf("erro:%s/n", mysql_error(&mysql));
}

*/
